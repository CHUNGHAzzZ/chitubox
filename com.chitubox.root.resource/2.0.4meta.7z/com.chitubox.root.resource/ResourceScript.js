
function appName()
{
    return installer.value("Name")
}

function serviceName()
{
    return (appName() + "-service")
}

function appExecutableFileName()
{
    if (runningOnWindows()) {
        return appName() + ".exe";
    } else {
        return appName();
    }
}

function runningOnWindows()
{
    return (systemInfo.kernelType === "winnt");
}

function runningOnMacOS()
{
    return (systemInfo.kernelType === "darwin");
}

function runningOnLinux()
{
    return (systemInfo.kernelType === "linux");
}


function Component()
{
}

Component.prototype.componentLoaded = function ()
{
    console.log("######Resource Component.prototype.componentLoaded");
}


Component.prototype.createOperations = function()
{
    component.createOperations();
    console.log("######Resource Component.prototype.createOperations");
    // installer.setValue("TargetDir", "C:/Users/soft/AppData/Local/CHITUBOX");
    // component.addElevatedOperation("Move", installer.value("TargetDir") + "/Resources", "C:/Users/soft/AppData/Local/CHITUBOX");

    if(runningOnWindows()){
        console.log("######runningOnWindows");
        
    } else if (runningOnMacOS()) {
       
    } else if (runningOnLinux()) {
       
    }
}

Component.prototype.installationFinished = function()
{
    console.log("######Component.prototype.installationFinished");
    
}
