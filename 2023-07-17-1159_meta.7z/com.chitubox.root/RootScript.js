
function appName()
{
    return installer.value("Name")
}

function serviceName()
{
    return (appName() + "-service")
}

function appExecutableFileName()
{
    if (runningOnWindows()) {
        return appName() + ".exe";
    } else {
        return appName();
    }
}

function runningOnWindows()
{
    return (systemInfo.kernelType === "winnt");
}

function runningOnMacOS()
{
    return (systemInfo.kernelType === "darwin");
}

function runningOnLinux()
{
    return (systemInfo.kernelType === "linux");
}

function vcRuntimeIsInstalled()
{
    return (installer.findPath("msvcp140.dll", [installer.value("RootDir")+ "\\Windows\\System32\\"]).length !== 0)
}

function moveResource()
{
    if(installer.status === QInstaller.Success){
        if (runningOnWindows()) {
            var TargetDir = "C:\\Users\\soft\\AppData\\Local\\CHITUBOX\\";
    
            if(!installer.fileExists(TargetDir)){ //不存在创建
                // var reuslt = installer.execute("md", [TargetDir]);
                // console.log("md reuslt:"+reuslt);

                component.addOperation("Mkdir", TargetDir);
            }
            else{ //存在则清空
    
            }
    
            var Dir = installer.value("TargetDir") + "\\Resources\\";
            var sourceDir = Dir.replace(/\//g,"\\");
            // var result = installer.execute("xcopy", [sourceDir, TargetDir,"/Y","/E"]);
            // console.log("xcopy result:" + result);
            component.addOperation("CopyDirectory",sourceDir,"C:\\Users\\soft\\AppData\\Local\\CHITUBOX\\");
            var result1 = component.addOperation("CopyDirectory",sourceDir,"C:\\Users\\soft\\AppData\\Local\\CHITUBOX\\");
            var result2 = component.addOperation("Move","E:\\111\\444","E:\\111\\111");

            // installer.performOperation("Delete","E:\\111\\1.txt");
            
            

        } else if (runningOnMacOS()) {
            
        } else if (runningOnLinux()) {
            
        }
    }
}

function Component()
{
    component.loaded.connect(this, Component.prototype.componentLoaded);
    installer.installationFinished.connect(this, Component.prototype.installationFinishedPageIsShown);
    installer.finishButtonClicked.connect(this, Component.prototype.installationFinished);
}

Component.prototype.componentLoaded = function ()
{

}

Component.prototype.installationFinishedPageIsShown = function()
{
    if (installer.isInstaller() && installer.status === QInstaller.Success) {
        gui.clickButton(buttons.FinishButton);
    }
}

Component.prototype.createOperations = function()
{
    component.createOperations();
    if(runningOnWindows()){
        if(installer.isInstaller()){
            component.addOperation("CreateShortcut", "@TargetDir@/" + appExecutableFileName(),
                        QDesktopServices.storageLocation(QDesktopServices.DesktopLocation) + "/" + appName() + ".lnk",
                        "workingDirectory=@TargetDir@", "iconPath=@TargetDir@\\" + appExecutableFileName(), "iconId=0");

            component.addElevatedOperation("CreateShortcut", "@TargetDir@/" + appExecutableFileName(),
                                        installer.value("AllUsersStartMenuProgramsPath") + "/" + appName() + ".lnk",
                                        "workingDirectory=@TargetDir@", "iconPath=@TargetDir@\\" + appExecutableFileName(), "iconId=0");
            
            if (!vcRuntimeIsInstalled()) {
                if (systemInfo.currentCpuArchitecture.search("64") < 0) {
                    component.addElevatedOperation("Execute", "@TargetDir@\\" + "vc_redist.x86.exe", "/install", "/quiet", "/norestart", "/log", "vc_redist.log");
                }
                else {
                    component.addElevatedOperation("Execute", "@TargetDir@\\" + "vc_redist.x64.exe", "/install", "/quiet", "/norestart", "/log", "vc_redist.log");
                }
            } else {
                console.log("Microsoft Visual C++ 2022 Redistributable already installed");
            }
        }
 
    } else if (runningOnMacOS()) {
        component.addElevatedOperation("Execute", "@TargetDir@/post_install.sh", "UNDOEXECUTE", "@TargetDir@/post_uninstall.sh");
    } else if (runningOnLinux()) {
        component.addElevatedOperation("Execute", "bash", "@TargetDir@/post_install.sh", "UNDOEXECUTE", "bash", "@TargetDir@/post_uninstall.sh");
    }

    // //移动资源文件
    // var TargetDir = "C:\\Users\\soft\\AppData\\Local\\CHITUBOX\\";
    // if(!installer.fileExists(TargetDir)){
    //     component.addOperation("Mkdir", TargetDir);
    // }

    // var Dir = installer.value("TargetDir") + "\\Resources\\";
    // var sourceDir = Dir.replace(/\//g,"\\");
    // component.addOperation("CopyDirectory",sourceDir,TargetDir);

    ////////////////
    // component.addOperation("Move","E:\\TestDir\\Test\\qqc\\1.txt","D:\\bd\\Test");
    // component.addElevatedOperation("Rmdir","E:\\TestDir\\bac");
    // component.addOperation("Execute" , "cmd","E:\\TestDir\\Test", "rd", "/s", "/q");
    // var result = installer.execute("rd", ["E:\\TestDir\\Test","/s","/q"]);
    // console.log("rd result:" + result);
}

Component.prototype.installationFinished = function()
{
    var command = "";
    var args = [];

    //安装完成，移动资源文件
    // moveResource();

    if ((installer.status === QInstaller.Success) && (installer.isInstaller() /*|| installer.isUpdater() // 更新不需要启动，部分组件更新会在程序运行中进行*/)) {

        if (!installer.gainAdminRights()) {
            console.log("Fatal error! Cannot get admin rights!")
            return
        }

        if (runningOnWindows()) {
            command = "@TargetDir@/" + appExecutableFileName()
        } else if (runningOnMacOS()) {
            command = "/Applications/" + appName() + ".app/Contents/MacOS/" + appName();
        } else if (runningOnLinux()) {
	        command = "@TargetDir@/client/" + appName();
	    }

        installer.dropAdminRights()
        console.log("///////installationFinished");
        processStatus = installer.executeDetached(command, args, installer.value("TargetDir"));
    }
}
